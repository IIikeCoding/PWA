-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 19, 2022 at 03:16 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE Projekt;
USE Projekt;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `Article`
--

CREATE TABLE `Article` (
  `id` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `newsBrief` varchar(100) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `category` varchar(35) DEFAULT NULL,
  `archived` int(11) NOT NULL,
  `dateOfArticle` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Article`
--

INSERT INTO `Article` (`id`, `title`, `newsBrief`, `content`, `image`, `category`, `archived`, `dateOfArticle`) VALUES
(32, '$_title', '$_brief', '$_newsContent', '$filename', '$_category', 1, '$_today'),
(44, 'God answers prayer', 'God Answers Prayers of Paralyzed Little Boy: ‘No,’ Says God\r\n\r\n', 'SAN FRANCISCO–For as long as he can remember, 7-year-old Timmy Yu has had one precious dream: From the bottom of his heart, he has hoped against hope that God would someday hear his prayer to walk again. Though many thought Timmy’s heavenly plea would never be answered, his dream finally came true Monday, when the Lord personally responded to the wheelchair-bound boy’s prayer with a resounding no.', 'cdgkjokpzkrhdoz2vbjv.png', 'Politics', 0, 'June 19, 2022'),
(45, 'World Death Rate', 'World Death Rate Holding Steady At 100 Percent', 'GENEVA, SWITZERLAND—World Health Organization officials expressed disappointment Monday at the group\'s finding that, despite the enormous efforts of doctors, rescue workers and other medical professionals worldwide, the global death rate remains constant at 100 percent.', 'epyvk05zkop8tmqmrdwo.png', 'Economy', 0, 'June 19, 2022'),
(46, 'Change', 'Black Guy Asks Nation For Change', 'CHICAGO—According to witnesses, a loud black man approached a crowd of some 4,000 strangers in downtown Chicago Tuesday and made repeated demands for change.\r\n\r\n“The time for change is now,” said the black guy, yelling at everyone within earshot for 20 straight minutes, practically begging America for change. “The need for change is stronger and more urgent than ever before. And only you—the people standing here today, and indeed all the people of this great nation—only you can deliver this change.”', 'Screenshot from 2022-06-19 14-50-26.png', 'Politics', 0, 'June 19, 2022'),
(47, 'Pie Eating', 'Winner Didn\'t Even Know It Was Pie-Eating Contest', 'Winner Didn\'t Even Know It Was Pie-Eating Contest', 'Screenshot from 2022-06-19 14-52-18.png', 'Politics', 0, 'June 19, 2022'),
(48, 'Dolphin Vacation', 'Dolphin Spends Amazing Vacation Swimming With Stockbroker', 'Describing the encounter as a once-in-a-lifetime experience she’ll never forget, local bottlenose dolphin Hazel reportedly recounted stories Tuesday from a recent vacation in which she got to go swimming with a stockbroker. “He was definitely shy at first, but with a little encouragement he swam right up next to me—the whole thing was so amazing,” said the dolphin, appearing excited as she described her “almost spiritual” encounter with the financial executive, whom she estimated was perhaps 40 years old and weighed as much as 180 pounds. “And he was just chattering away the whole time. It’s like they have their own little language. You have to wonder what’s going on in their heads and whether it’s true that they’re almost as intelligent as we are.” The dolphin added that while she ultimately enjoyed her experience, she was disappointed that she wasn’t allowed to actually ride the stockbroker.', 'Screenshot from 2022-06-19 14-53-54.png', 'Politics', 0, 'June 19, 2022'),
(49, 'Archaeological Dig', 'Archaeological Dig Uncovers Ancient Race Of Skeleton People', 'A team of British and Egyptian archaeologists made a stunning discovery Monday, unearthing several intact specimens of “skeleton people”—skinless, organless humans who populated the Nile delta region an estimated 6,000 years ago.', 'Screenshot from 2022-06-19 14-57-19.png', 'Politics', 0, 'June 19, 2022'),
(50, 'Sonic', '‘Nothing Is More Attractive Than Confidence,’ Says Woman Who Has Never Seen Sonic The Hedgehog', 'Naively insisting that we seek partners with the confidence to be comfortable in their own skin, Denver systems analyst Jennifer Thomas, 32, stated Monday that “nothing is more attractive than confidence,” clearly demonstrating that she has never seen Sonic the Hedgehog cosplay. “Being secure with who you are is really the sexiest thing a person can do,” said Thomas, who has never witnessed an obese, mustachioed Sonic, an orange-cutoff-clad Tails, and a sweat-soaked Knuckles the Echidna enter a convention center to join up with hundreds of Charmy Bees, Espio the Chameleons, and Rouge the Bats who await them for a day chock-full of roleplaying on planet Mobius. “Honestly, I believe it’s about the way you carry yourself. I think it’s apparent that if we first love ourselves, then others [as long as you’ve never seen a tattoo-covered Sonic wage a ham-fisted mock battle with a rotund, middle-aged Dr. Robotnik in order to gain the sixth Chaos Emerald and enter a Comic Con booth labeled ‘Cr', 'Screenshot from 2022-06-19 15-00-07.png', 'Politics', 0, 'June 19, 2022'),
(51, 'Cia Realizes', 'CIA Realizes It\'s Been Using Black Highlighters All These Years', 'LANGLEY, VA—A report released Tuesday by the CIA’s Office of the Inspector General revealed that the CIA has mistakenly obscured hundreds of thousands of pages of critical intelligence information with black highlighters.', 'Screenshot from 2022-06-19 15-02-36.png', 'Politics', 0, 'June 19, 2022'),
(52, 'Loki ', '‘Loki’ Fan Loves How Show Contains So Many References To Loki', 'Expressing his enthusiasm over the Disney+ series, area Loki fan Kent Milner told reporters Friday that he loved how the show contained so many references to Loki. “It’s a real treat for MCU fanatics like myself to see the creators include so many subtle nods to the Asgardian God of Mischief in the design, dialogue, and even title of the show,” said Milner, confirming that the show’s first two episodes had already included multiple easter eggs about Loki’s past and upcoming role in the Marvel universe virtually every time Tom Hiddleston appeared onscreen.', 'Screenshot from 2022-06-19 15-09-09.png', 'Culture', 0, 'June 19, 2022'),
(53, 'Testt', 'Testtttttttttttt', 'tttttttttttttt', 'Screenshot from 2022-06-16 22-27-31.png', 'Sports', 1, 'June 19, 2022');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `levelOfUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`username`, `password`, `levelOfUser`) VALUES
('admin', '$2y$10$bdj5Cfgm7ItjjvGUdgC70.RpLwA/hVj1/MaCgWSj2hK0N9n3mq8di', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Article`
--
ALTER TABLE `Article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Article`
--
ALTER TABLE `Article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
