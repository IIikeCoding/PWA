<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>

<div id="content-wrapper">
<header>

    <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
    
    <hr>
    <nav>

        <a href="index.php">HOME</a>
        <a href="kategorija.php?category=Sports">SPORTS</a>
        <a href="kategorija.php?category=Culture">CULTURE</a>
        <a href="kategorija.php?category=Politics">POLITICS</a>
        <a href="kategorija.php?category=Economy">ECONOMY</a>
        <a href="prijava.php">LOGIN</a>

    </nav>
</header>




<section id="formSection">

    <form name="register" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">


        <label for="username">Please enter your username</label>
        <input type="text" name="username" id="username">

        <label for="password">Please enter your password</label>
        <input type="password" name="password" id="password">

        <label for="repeatPassword">Please enter your password</label>
        <input type="password" name="repeatPassword" id="repeatPassword">

        <label for="levelOfUser">News Category</label>
        <select name="levelOfUser" id="levelOfUser">

            <option value="" selected disabled hidden>Choose here</option>
            <option value="Admin">Admin</option>
            <option value="Regular">Regular</option>
        
        </select>

        <br>
        <button type="submit" name="register">register</button>

    </form>

    

    <?php 

        if( isset($_POST['register'])){

            $_hostname = "localhost";
            $_username = "root";
            $_password = "";
            $_database = "Projekt";

            $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

            if(!$databaseConnnection){
                echo "Could not connect to database";
            }

            $_nameOfUser = $_POST['username'];
            $_passwordOfUser = password_hash($_POST['password'],PASSWORD_BCRYPT);
            $_lvl = $_POST['levelOfUser'];

            
            $_checkUsername=mysqli_stmt_init($databaseConnnection);

            mysqli_stmt_prepare($_checkUsername,"SELECT * FROM User WHERE User.username = ?;");

            mysqli_stmt_bind_param($_checkUsername, 's', $_nameOfUser);
            mysqli_stmt_execute($_checkUsername);
            mysqli_stmt_store_result($_checkUsername);

        
            if(mysqli_stmt_num_rows($_checkUsername) == 0){

                if($_lvl == 'Admin')
                    $_levelOfUser = 1;
                else
                    $_levelOfUser = 0;
                
                $stmt=mysqli_stmt_init($databaseConnnection);
                mysqli_stmt_prepare($stmt,"INSERT INTO User (username, password, levelOfUser) VALUES (?, ?, ?);");
                mysqli_stmt_bind_param($stmt, 'ssi', $_nameOfUser, $_passwordOfUser, $_levelOfUser);
                mysqli_stmt_execute($stmt);
                

                echo "<p>Thank you for registering</p>";

                mysqli_close($databaseConnnection);
                sleep(1);
                
                header('Location: http://localhost/webalizer/Surina_Denis_0246098762/prijava.php');


            }else{

                echo "<p>Sorry,that username already exists</p>";

            }
            
            
            $_POST = array();
            mysqli_close($databaseConnnection);

        }

?>
</section>

</div>

<footer>
    <div id="footerDiv">
        <hr>
        <a href="#somewhere">&amp;Le Parisien</a>
        <div id="name-email-div">
            <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
        </div>
    </div>
</footer>


<script>

        jQuery(document).ready(function(){
            $("form[name='register']").validate({
                rules: {
                    username: {
                        required: true,
                        minlength: 5,
                        maxlength: 32
                    },
                    
                    password: {
                        required: true,
                        minlength: 5,
                        maxlength: 100
                    },
                    repeatPassword: {
                        required: true,
                        equalTo: "#password"
                    },
                    levelOfUser: {
                        required: true,
                    },

                },
                messages: {
                    username: {
                        required: "Please enter username",
                        minlength: "username must be atleast 5 char",
                        maxlength: "cant be more than 32 characters"
                    },
                    
                    password: {
                        required: "Please enter your password",
                        minlength: "password must be atleast 5 char",
                        maxlength: "cant be more than 100 characters"
                    },
                    repeatPassword: {
                        required: "please reapeat password",
                        equalto: "password must be the same"
                    },
                    levelOfUser: {
                        required: "please select level of user",
                    },
                },
                
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
        
        
    </script>

    
</body>
</html>