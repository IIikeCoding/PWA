<!DOCTYPE html>

<html>

<head>
    <title>pocetna</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style/style.css">
</head>

<body class="body">

    <?php 
        
        $_hostname = "localhost";
        $_username = "root";
        $_password = "";
        $_database = "Projekt";

        $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

        if(!$databaseConnnection){
            echo "Could not connect to database";
        }

        $my_array = array("Sports","Culture","Politics","Economy");
        shuffle($my_array);
        $_category1 = $my_array[0];
        $_category2 = $my_array[1];

        

    ?>
    
    <header>

        <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
       
        <hr>
        <nav>

            <a href="index.php">HOME</a>
            <a href="kategorija.php?category=Sports">SPORTS</a>
            <a href="kategorija.php?category=Culture">CULTURE</a>
            <a href="kategorija.php?category=Politics">POLITICS</a>
            <a href="kategorija.php?category=Economy">ECONOMY</a>
            <a href="prijava.php">LOGIN</a>

        </nav>
    </header>

    <div id="content-wrapper">


        <section class="section" id="firstSection">

            <hr>
            <h2><?php echo $_category1; ?></h2>        

            <div class="newsSection">

                <?php


                    $_selectCategoryQuery = "SELECT * FROM Article WHERE Article.category=? AND Article.archived=0;";
                    $stmt = mysqli_prepare($databaseConnnection, $_selectCategoryQuery);
                    
                    mysqli_stmt_bind_param($stmt, 's',$_category1);
                    mysqli_stmt_execute($stmt);

                    $result = mysqli_stmt_get_result($stmt);
                    
                    if($result){

                        $_numberOfRows = mysqli_num_rows($result);
                        $_numberOfIterations = 3;

                        if($_numberOfRows < 3  && $_numberOfRows > 0)
                            $_numberOfIterations = $_numberOfRows;
                        elseif($_numberOfRows == 0){
                            echo "<p id='no-article-msg'> Sorry no articles for this category.Please add some.</p>";
                            $_numberOfIterations = 0;
                        }

                        for( $i = 0; $i < $_numberOfIterations; $i++){

                            $_firstRow = mysqli_fetch_assoc($result);
                            
                            
                            echo "<a href='article.php?id=".$_firstRow['id']."' id='index-article'>
                                    <article>
                                        <img src='images/".$_firstRow['image']."'>
                                        <h3>".$_firstRow['title']."</h3>
                                        <p>".$_firstRow['newsBrief']."</p>
                                    </article>
                                </a>";
                        }
            
                    }

                ?>
            </div>

        </section>

        <section class="section" id="secondSection">

            <hr>
            <h2><?php echo $_category2; ?></h2>

            <div class="newsSection">
                <?php

                    mysqli_stmt_bind_param($stmt, 's',$_category2);
                    mysqli_stmt_execute($stmt);

                    $_secondResult = mysqli_stmt_get_result($stmt);

                    if($_secondResult){

                        $_numberOfRows = mysqli_num_rows($_secondResult);
                        $_numberOfIterations = 3;

                        if($_numberOfRows < 3 && $_numberOfRows > 0)
                            $_numberOfIterations = $_numberOfRows;
                        elseif($_numberOfRows == 0){
                            echo "<p id='no-article-msg'> Sorry no articles for this category.Please add some.</p>";
                            $_numberOfIterations = 0;
                        }
                        
                        for( $i = 0; $i < $_numberOfIterations; $i++){

                            $_secondRow = mysqli_fetch_assoc($_secondResult);
                            
                            echo "<a href='article.php?id=".$_secondRow['id']."' id='index-article'>
                                    <article>
                                        <img src='images/".$_secondRow['image']."'>
                                        <h3>".$_secondRow['title']."</h3>
                                        <p>".$_secondRow['newsBrief']."</p>
                                    </article>
                                </a>";
                        }

                    }
                    mysqli_close($databaseConnnection);
                ?>
            </div>
        </section>
        
    </div>
    <footer>
        <div id="footerDiv">
            <hr>
            <a href="#somewhere">&amp;Le Parisien</a>
            <div id="name-email-div">
                <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
            </div>
        </div>
    </footer>

</body>

</html>