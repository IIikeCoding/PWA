<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Article</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>

    <?php

        error_reporting(0);

        $_hostname = "localhost";
        $_username = "root";
        $_password = "";
        $_database = "Projekt";
       
        $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

        if(!$databaseConnnection){
            echo "Could not connect to database";
        }

        $_articleId = $_GET['id'];

        $_query = "SELECT * FROM Article WHERE Article.id = ?";

        $stmt = mysqli_prepare($databaseConnnection, $_query);
       
        mysqli_stmt_bind_param($stmt,'i',$_articleId);
        mysqli_stmt_execute($stmt);
        
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

    ?>

    <header>
        <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
        <hr>
        <nav>
            <a href="index.php">HOME</a>
            <a href="kategorija.php?category=Sports">SPORTS</a>
            <a href="kategorija.php?category=Culture">CULTURE</a>
            <a href="kategorija.php?category=Politics">POLITICS</a>
            <a href="kategorija.php?category=Economy">ECONOMY</a>
            <a href="prijava.php">LOGIN</a>

        </nav>
    </header>

    <section id="articleSection">

        <h1><?php echo  $row['category']; ?></h1>

        <p id="date"><?php echo  $row['dateOfArticle']; ?></p>

        <img src="<?php echo "images/".$row['image']; ?>" alt="">

        <p><?php echo $row['newsBrief'];?></p>

        <h3><?php echo $row['title']; ?></h3>
        
        <p><?php echo $row['content']; ?></p>
        
    </section>

    <footer>
            <div id="footerDiv">
                <hr>
                <a href="#somewhere">&amp;Le Parisien</a>
                <div id="name-email-div">
                    <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
                </div>
            </div>
    </footer>

</body>
</html>