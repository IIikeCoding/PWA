<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>


    <?php

        $_hostname = "localhost";
        $_username = "root";
        $_password = "";
        $_database = "Projekt";

        $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

        if(!$databaseConnnection){
            echo "Could not connect to database";
        }
    
    ?>


    <header>

        <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
       
        <hr>
        <nav>

            <a href="index.php">HOME</a>
            <a href="kategorija.php?category=Sports">SPORTS</a>
            <a href="kategorija.php?category=Culture">CULTURE</a>
            <a href="kategorija.php?category=Politics">POLITICS</a>
            <a href="kategorija.php?category=Economy">ECONOMY</a>
            <a href="prijava.php">LOGIN</a>

        </nav>
    </header>


    <section id="formSection"> 

    <h1>Edit articles</h1>

    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">

        <label for="categorySelect">Select a category</label>
        <select name="categorySelect" id="categorySelect">

                    <option value="" selected disabled hidden>Choose here</option>
                    <option value="Sports">Sports</option>
                    <option value="Culture">Culture</option>
                    <option value="Politics">Politics</option>
                    <option value="Economy">Economy</option>

        </select>
        <br>
        <button name="display" type="submit">Display</button>

    </form>


    <?php 
    
        if( isset($_POST['display']) && !empty($_POST['categorySelect'])){

            $category = $_POST['categorySelect'];

            $_sql = "SELECT * FROM Article WHERE Article.category = ?;";
            $stmt = mysqli_prepare($databaseConnnection, $_sql);    
            mysqli_stmt_bind_param($stmt, 's',$category);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if($result){
                
                echo "<ul>";
                while($row = mysqli_fetch_assoc($result)){
                    echo "<li><a class=\"categoryListLink\" href='editArticle.php?id=".$row['id']."'>"
                    .$row['title']."<br>
                    Datum:".$row['dateOfArticle']."<br>
                    ".$row['newsBrief']."
                    </a></li><br>";
                }
                echo "</ul>";

            }


            mysqli_close($databaseConnnection);

        }
        
    
    ?>

    </section>



    <footer>
        <div id="footerDiv">
            <hr>
            <a href="#somewhere">&amp;Le Parisien</a>
            <div id="name-email-div">
                <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
            </div>
        </div>
    </footer>
    
</body>
</html>