<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Article</title>
    <link rel="stylesheet" href="style/style.css">
</head>

<body>
        <?php

            error_reporting(0);

            $_hostname = "localhost";
            $_username = "root";
            $_password = "";
            $_database = "Projekt";

            $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

            if(!$databaseConnnection){
                echo "Could not connect to database";
            }

            if (isset($_POST["upload"])){

                $_today = date("F j, Y");

                
                $_title = $_POST['newsTitle'];
                $_brief = $_POST['newsBrief'];
                $_newsContent = $_POST['newsContent'];
                $_category = $_POST['newsCategory'];

                $_archived;

                if($_POST['archiveSave'] == "on"){
                    $_archived = 1;
                }else
                    $_archived = 0;

                $filename = $_FILES['imageNews']['name'];

                $tempname = $_FILES['imageNews']['tmp_name'];  

                $folder = "images".DIRECTORY_SEPARATOR.$filename;


                $sql = "INSERT INTO Article ( title, newsBrief, content, image, category, archived, dateOfArticle)
                 VALUES ( ?, ?, ?, ?, ?, ?, ?);";

                $stmt = mysqli_stmt_init($databaseConnnection);
                mysqli_stmt_prepare($stmt, $sql);
                mysqli_stmt_bind_param($stmt,'sssssis',$_title, $_brief, $_newsContent, $filename, $_category, $_archived, $_today);
                
                mysqli_stmt_execute($stmt);
               
                if (move_uploaded_file($tempname, $folder))
                    $msg = "Image uploaded successfully";
                else
                    $msg = "Failed to upload image";
                    
            }


            mysqli_close($databaseConnnection);
        
        ?>

    <header>
        
        <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
    
        <hr>
        <nav>

            <a href="index.php">HOME</a>
            <a href="kategorija.php?category=Sports">SPORTS</a>
            <a href="kategorija.php?category=Culture">CULTURE</a>
            <a href="kategorija.php?category=Politics">POLITICS</a>
            <a href="kategorija.php?category=Economy">ECONOMY</a>
            <a href="prijava.php">LOGIN</a>

        </nav>
    </header>

    <section id="articleSection">

        <h1><?php echo $_category; ?></h1>

        <p id="date"><?php echo $_today; ?></p>

        <img src="<?php echo "images/".$filename; ?>" alt="">

        <p><?php echo $_brief?></p>

   

        <h3><?php echo $_title; ?></h3>
        
        <p><?php echo $_newsContent; ?></p>
        
    </section>

    <footer>
            <div id="footerDiv">
                <hr>
                <a href="#somewhere">&amp;Le Parisien</a>
                <div id="name-email-div">
                    <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
                </div>
            </div>
    </footer>
    

</body>
</html>