<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
<div id="content-wrapper">

    <?php

        $_hostname = "localhost";
        $_username = "root";
        $_password = "";
        $_database = "Projekt";

        $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

        if(!$databaseConnnection){
            echo "Could not connect to database";
        }

        $_articleId = $_GET['id'];
        $_articleId = $_GET['id'];
    ?>


    <header>

        <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
       
        <hr>
        <nav>

            <a href="index.php">HOME</a>
            <a href="kategorija.php?category=Sports">SPORTS</a>
            <a href="kategorija.php?category=Culture">CULTURE</a>
            <a href="kategorija.php?category=Politics">POLITICS</a>
            <a href="kategorija.php?category=Economy">ECONOMY</a>
            <a href="prijava.php">LOGIN</a>

        </nav>
    </header>


    <section id="formSection">

        <h1>Edit articles</h1>

        <p>Input only field you would like to change</p>

        <form enctype="multipart/form-data"  action="<?php echo $_SERVER['PHP_SELF']."?id=".$_articleId.""; ?>" method="post">

            <label for="newsTitle">New Title</label>
            <input type="text" name="newsTitle" id="newsTitle" maxlength="30">

            <label for="newsBrief">New Brief</label>
            <textarea name="newsBrief" id="newsBrief" cols="30" rows="10" maxlength="100"></textarea>

            <label for="newsContent">New Content</label>
            <textarea name="newsContent" id="newsContent" cols="30" rows="10" maxlength="999"></textarea>

            <label for="imageNews">New Image</label>
            <input type="file" name="imageNews" id="imageNews" accept="image/*">

            <label for="newsCategory">New Category</label>
            <select name="newsCategory" id="newsCategory">

                <option value="" selected disabled hidden>Choose here</option>
                <option value="Sports">Sports</option>
                <option value="Culture">Culture</option>
                <option value="Politics">Politics</option>
                <option value="Economy">Economy</option>

            </select>

            <label for="archiveSave">Save to archive</label>
            <input type="checkbox" name="archiveSave" id="archiveSave">



            <button type="submit" name="uploadNew" id="uploadNew">Send</button>
            <br>
            <button type="reset">Reset</button>
            <br>
            <button type="submit" name="deleteArticle" id="deleteArticle">Delete Post</button>

        </form>


        <?php
            $_articleId = $_GET['id'];
            if(isset($_POST['uploadNew'])){

                if(!empty($_POST['newsTitle'])){
                    $addNewTitleSql = "UPDATE Article SET Article.title = ? WHERE Article.id = ?;";
                    $stmt = mysqli_prepare($databaseConnnection, $addNewTitleSql);    
                    mysqli_stmt_bind_param($stmt, 'si',$_POST['newsTitle'],$_articleId);
                    mysqli_stmt_execute($stmt);
                }

                if(!empty($_POST['newsBrief'])){
                    $addNewBriefSql = "UPDATE Article SET Article.newsBrief = ? WHERE Article.id = ?;";
                    $stmt = mysqli_prepare($databaseConnnection, $addNewBriefSql);    
                    mysqli_stmt_bind_param($stmt, 'si',$_POST['newsBrief'],$_articleId);
                    mysqli_stmt_execute($stmt);
                }

                if(!empty($_POST['newsContent'])){
                    $addNewContentSql = "UPDATE Article SET Article.content = ? WHERE Article.id = ?;";
                    $stmt = mysqli_prepare($databaseConnnection, $addNewContentSql);    
                    mysqli_stmt_bind_param($stmt, 'si',$_POST['newsContent'],$_articleId);
                    mysqli_stmt_execute($stmt);
                }


                
                if( !empty($_FILES['imageNews']['name'])){

                    $filename = $_FILES['imageNews']['name'];

                    $tempname = $_FILES['imageNews']['tmp_name'];  

                    $folder = "images".DIRECTORY_SEPARATOR.$filename;

                    $addNewImageSql = "UPDATE Article SET Article.image = ? WHERE Article.id = ?;";
                    $stmt = mysqli_prepare($databaseConnnection, $addNewImageSql);    
                    mysqli_stmt_bind_param($stmt, 'si', $filename, $_articleId);
                    mysqli_stmt_execute($stmt);

                    move_uploaded_file($tempname, $folder);

                }

                if(!empty($_POST['newsCategory'])){
                    $addNewCategorySql = "UPDATE Article SET Article.category = ? WHERE Article.id = ?;";
                    $stmt = mysqli_prepare($databaseConnnection, $addNewCategorySql);    
                    mysqli_stmt_bind_param($stmt, 'si',$_POST['newsCategory'],$_articleId);
                    mysqli_stmt_execute($stmt);
                }

                

                if($_POST['archiveSave'] == "on"){
                    $_archived = 1;
                }else
                    $_archived = 0;

                $addNewArchivedSql = "UPDATE Article SET Article.archived = ? WHERE Article.id = ?;";
                $stmt = mysqli_prepare($databaseConnnection, $addNewArchivedSql);    
                mysqli_stmt_bind_param($stmt, 'ii', $_archived ,$_articleId);
                mysqli_stmt_execute($stmt);
            

                echo "<a href='article.php?id=".$_articleId."'> Preview </a>";

               
                
                
            }elseif( isset($_POST['deleteArticle'])){

                $sql = "DELETE FROM Article WHERE Article.id = ?;";
                $stmt = mysqli_prepare($databaseConnnection, $sql);    
                mysqli_stmt_bind_param($stmt, 'i', $_articleId);
                mysqli_stmt_execute($stmt);

                
                header("Location:administrator.php");

            }

           
            mysqli_close($databaseConnnection);

        ?>


    </section>

</div>

    <footer>
        <div id="footerDiv">
            <hr>
            <a href="#somewhere">&amp;Le Parisien</a>
            <div id="name-email-div">
                <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
            </div>
        </div>
    </footer>
    
</body>
</html>