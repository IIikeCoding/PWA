<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>

    <link rel="stylesheet" href="style/style.css?v=<?php echo time(); ?>">
    
</head>
<body>

<div id="content-wrapper">
<header>

    <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
    
    <hr>
    <nav>

        <a href="index.php">HOME</a>
        <a href="kategorija.php?category=Sports">SPORTS</a>
        <a href="kategorija.php?category=Culture">CULTURE</a>
        <a href="kategorija.php?category=Politics">POLITICS</a>
        <a href="kategorija.php?category=Economy">ECONOMY</a>
        <a href="prijava.php">LOGIN</a>

    </nav>
</header>




<section id="formSection">

    <form id="formLogin" name="login" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">


        <label for="username">Please enter your username</label>
        <input type="text" name="username" id="username">

        <label for="password">Please enter your password</label>
        <input type="password" name="password" id="password">

        <br>

        <button type="submit" name="login" id="login">Login</button>

    </form>

    

    <?php 

        if( isset($_POST['login'])){

            $_hostname = "localhost";
            $_username = "root";
            $_password = "";
            $_database = "Projekt";

            $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

            if(!$databaseConnnection){
                echo "Could not connect to database";
            }

            $_name = $_POST['username'];
            $_password = $_POST['password'];

            $_query = mysqli_stmt_init($databaseConnnection);
            mysqli_stmt_prepare($_query,"SELECT * FROM User WHERE User.username=?;");
            mysqli_stmt_bind_param($_query,'s',$_name);
            mysqli_stmt_execute($_query);
            mysqli_stmt_store_result($_query);

            if(mysqli_stmt_num_rows($_query)>0){

                mysqli_stmt_bind_result($_query, $resultUsername,$resultPassword,$resultLevel);
                mysqli_stmt_fetch($_query); 

                if( password_verify($_password, $resultPassword )){
                    
                    if($resultLevel == 1){

                        echo "<br>Welcome ".$resultUsername." . you are an admin<br>";
                        echo "<br><a  href='administrator.php'><button class=\"loginButton\"'>Edit Articles</button></a>";
                        echo "<br><a href='unos.html'><button class=\"loginButton\">Add new Article</button></a>";

                    }else{
                        echo "<br>Welcome ".$resultUsername.".You do not have admin clearance";
                    }

                }else{
                    echo "<br><p>Wrong password</p>";
                }

            }else{
                echo "<br><p>That user does not exist.Would you like to register?</p>";
                echo "<a href='registracija.php'>yes</a>";
            }
            
            mysqli_close($databaseConnnection);
        }


    ?>
</section>

</div>

<footer>
    <div id="footerDiv">
        <hr>
        <a href="#somewhere">&amp;Le Parisien</a>
        <div id="name-email-div">
            <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
        </div>
    </div>
</footer>


<script>

        jQuery(document).ready(function(){
            $("form[name='login']").validate({
                rules: {
                    username: {
                        required: true,
                    },
                    
                    password: {
                        required: true,
                    }
                },
                messages: {
                    username: {
                        required: "Username cant be empty",
                    },
                    password: {
                        required: "Password cant be empty",
                    }
                },
                
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
        
        
    </script>

    
</body>
</html>