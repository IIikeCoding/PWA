<!DOCTYPE html>

<html>

<head>
    <title>Kategorija</title>
    <meta charset="UTF-8">

    <link rel="stylesheet" href="style/style.css">

</head>

<body class="body">
    
    <?php 
    
        $_category = $_GET['category'];

        $_hostname = "localhost";
        $_username = "root";
        $_password = "";
        $_database = "Projekt";

        $databaseConnnection =  mysqli_connect($_hostname, $_username, $_password, $_database);

        if(!$databaseConnnection){
            echo "Could not connect to database";
        }

        
    
    
    ?>
    
    <header>

        <div id="img"> <img src="images/logo_header.png" alt="logo_header"></div>
       
        <hr>
        <nav>

            <a href="index.php">HOME</a>
            <a href="kategorija.php?category=Sports">SPORTS</a>
            <a href="kategorija.php?category=Culture">CULTURE</a>
            <a href="kategorija.php?category=Politics">POLITICS</a>
            <a href="kategorija.php?category=Economy">ECONOMY</a>
            <a href="prijava.php">LOGIN</a>

        </nav>
    </header>
    
    
    
    <section id="singleCategorySection">
        <h2><?php echo $_category;?></h2>
        <?php
            
            $_query = "SELECT * FROM Article WHERE Article.category=? AND Article.archived=0;";

            $stmt = mysqli_prepare($databaseConnnection, $_query);
                    
            mysqli_stmt_bind_param($stmt, 's',$_category);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            
            if($result){
    
                while($row = mysqli_fetch_assoc($result)){

                    echo   "<a href='article.php?id=".$row['id']."' id='categoryArticleLink'>
                                <article>
                                    <img src='images/".$row['image']."'>
                                    <h3>". $row['title'] ."</h3>
                                    <p>".$row['newsBrief']."</p>
                                </article>
                            </a>";

                }
    
            }


            mysqli_close($databaseConnnection);
        
        ?>
        

    </section>
    
    <footer>
        <div id="footerDiv">
            <hr>
            <a href="#somewhere">&amp;Le Parisien</a>
            <div id="name-email-div">
                <p>Šurina Denis &nbsp; dsurina@tvz.hr</p>
            </div>
        </div>
    </footer>

</body>

</html>